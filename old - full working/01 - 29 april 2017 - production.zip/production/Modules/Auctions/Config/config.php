<?php

return [
    'name' => 'Auctions'
];
