<?php

return [
    'name' => 'CarCompanies'
];
