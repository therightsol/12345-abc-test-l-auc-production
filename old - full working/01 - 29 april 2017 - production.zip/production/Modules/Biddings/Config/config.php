<?php

return [
    'name' => 'Biddings'
];
